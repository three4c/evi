import{r as n,j as t,R as c,a as p}from"./insert-Cz5GglqO.js";const a=()=>{const s=()=>chrome.runtime.openOptionsPage(),i=`aaaaa
bbbbb
ccccc`;return n.useEffect(()=>{},[]),t.jsxs("div",{className:"App",children:[t.jsx("span",{className:"App__icon",children:"🦐"}),t.jsx("p",{className:"App__text",children:"evi"}),t.jsx("button",{type:"button",className:"App__settings",onClick:s,children:"⚙️"})]})},e=document.getElementById("root");e&&c.createRoot(e).render(t.jsx(p.StrictMode,{children:t.jsx(a,{})}));
